package myy803.courses_mgt_app_skeleton.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import myy803.courses_mgt_app_skeleton.dao.CourseDAO;
import myy803.courses_mgt_app_skeleton.entity.Course;
import myy803.courses_mgt_app_skeleton.entity.StudentRegistration;
import myy803.courses_mgt_app_skeleton.entity.User;
import myy803.courses_mgt_app_skeleton.service.statistics.StatisticStrategy;

@Service
public  class CourseServiceImpl implements CourseService {
	
	@Autowired
	private CourseDAO courseRepository;
	private User user;
	private List<StatisticStrategy> ObjectStatisticStrategies;

	private List<StudentRegistration> StudentRegistrations;
	
	StatisticStrategy ObjectStatisticStrategy;

	public CourseServiceImpl() {
		super();
	}

	@Autowired
	public CourseServiceImpl(CourseDAO theCourseRepository) {
		courseRepository = theCourseRepository;
	}
	
	@Override
	@Transactional
	public List<Course> findAll() {
		return courseRepository.findAll();
	}
	
	@Override
	@Transactional
	//@Query("SELECT * FROM course WHERE course.usrname = usrname")
	public List<Course> findByUsrname(String usrname)  {
		
		 List<Course> c = courseRepository.findByUsrname(usrname);
		 return c;
		 }
	
	@Override
	@Transactional
	public void deleteById(int id) {
		courseRepository.deleteById(id);
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	@Override
	public Course findById(int courseId) {
		Course course =	courseRepository.findById(courseId);
		return course;
		
	}

	@Override
	@Transactional
	public Course saveCourse(Course theCourse) {
		Course courseresponse = courseRepository.save(theCourse);
		return courseresponse;
	}
	public int  getCourseIdByUsrname(String usrname) {
		return courseRepository.getCourseIdByUsrname(usrname);
	}
	
	public boolean addStudentRegistration(StudentRegistration studentregistration) {
		return StudentRegistrations.add(studentregistration);
	}
	///Methods for statistic results
	public List<StatisticStrategy> getStatCalculationStrategies() {
		return ObjectStatisticStrategies;
		
	}

	public void setStatCalculationStrategies(List<StatisticStrategy> ObjectStatisticStrategies) {
		this.ObjectStatisticStrategies =  ObjectStatisticStrategies;
	
		
	}
	public Map<String,Double> getCourseStatistics(String name,Course course) {
		 Map<String,Double> CourseAndStat = new HashMap<>();
		
	
		 double val =  ObjectStatisticStrategy.calculateStatistic(course);
		 
		// getStatCalculationStrategies().add(ObjectStatisticStrategy);
		  CourseAndStat.put(name,val);
	

		  return CourseAndStat;
	}
	
	


	
}

