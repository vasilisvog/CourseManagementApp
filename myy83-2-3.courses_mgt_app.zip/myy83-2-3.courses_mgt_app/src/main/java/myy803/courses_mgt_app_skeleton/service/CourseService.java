package myy803.courses_mgt_app_skeleton.service;

import java.util.List;
import myy803.courses_mgt_app_skeleton.entity.Course;
import myy803.courses_mgt_app_skeleton.entity.StudentRegistration;

public interface CourseService {

	public List<Course> findAll();
	public List<Course> findByUsrname(String username);
	public void deleteById(int id);
	public Course saveCourse(Course theCourse);
	public Course findById(int id);
	public int getCourseIdByUsrname(String usrname);
	public boolean addStudentRegistration(StudentRegistration studentregistration);
	
	
	
	



	
	
}