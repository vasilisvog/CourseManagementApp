package myy803.courses_mgt_app_skeleton.service.statistics;

import org.apache.commons.math3.stat.descriptive.DescriptiveStatistics;

import myy803.courses_mgt_app_skeleton.entity.Course;
//  extends Adaptee implements StatisticStrategy 
public class StatisticStrategyAdapter{
//	DescriptiveStatistics descriptiveStatistics = new DescriptiveStatistics();
	
//	@Override
	//public double calculateStatistic(Course course) {
		// TODO Auto-generated method stub
	//	String adaptedData =  new Double()
		//return 0;
	//}
//DescriptiveStatistics object to create a dataset that contains the students grades and then calculate the corresponding statistic.
//}
//@Override
//public void request(int data) {
//	String adaptedData = new Integer(data).toString();
//	super.specificRequest(adaptedData);
}