package myy803.courses_mgt_app_skeleton.service.statistics;

public class TemplateFactory {
	public static TemplateStatisticStrategy create(String choice) {
		if(choice.equals("Skewness"))
			return new SkewnessStatisticStrategy();
		else
			return new MeanStatisticStrategy();
	}

}
