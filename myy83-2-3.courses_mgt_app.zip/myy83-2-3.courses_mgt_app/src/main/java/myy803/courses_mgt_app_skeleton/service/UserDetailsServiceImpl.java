package myy803.courses_mgt_app_skeleton.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.*;
import myy803.courses_mgt_app_skeleton.dao.UserRepository;
import myy803.courses_mgt_app_skeleton.entity.User;

public class UserDetailsServiceImpl implements UserDetailsService {
	
    @Autowired
    private UserRepository userRepository;

    @Override
    public UserDetails loadUserByUsername(String username)
            throws UsernameNotFoundException {
    User user = userRepository.getUserByUsername(username);
         
        if (user == null) {
            throw new UsernameNotFoundException("Could not find user");
        }
         
         UserDetails user2 = new MyUserDetails(user);
     
        return  user2;
    }


	public User findByUserId(int id) {
		return userRepository.findById(id);
	}
	public User save(User user) {
		return userRepository.save(user);
	}


}