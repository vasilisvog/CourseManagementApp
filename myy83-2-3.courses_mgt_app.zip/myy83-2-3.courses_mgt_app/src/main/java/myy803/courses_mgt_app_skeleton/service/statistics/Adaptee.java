package myy803.courses_mgt_app_skeleton.service.statistics;

public class Adaptee {
//	public void specificcalculateStatistic() {
		
	//}
}
