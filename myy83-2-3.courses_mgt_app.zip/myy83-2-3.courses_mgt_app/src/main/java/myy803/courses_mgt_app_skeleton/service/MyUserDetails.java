package myy803.courses_mgt_app_skeleton.service;

import java.util.*;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import myy803.courses_mgt_app_skeleton.entity.Role;
import myy803.courses_mgt_app_skeleton.entity.User;

public class MyUserDetails implements UserDetails {
	// MyUserDetails is implemented by UserDetailsServiceImpl
	private static final long serialVersionUID = 5906029077878384248L; // eclipse suggestion
	private User user;
    
	public MyUserDetails(User user) {
       this.user = user;
   }
	//Roles for login authentication
   @Override
   public Collection<? extends GrantedAuthority> getAuthorities() {
       Set<Role> roles = user.getRoles();
       List<SimpleGrantedAuthority> authorities = new ArrayList<>();
        
       for (Role role : roles) {
           authorities.add(new SimpleGrantedAuthority(role.getName()));
       }
        
       return authorities;
   }

   @Override
   public String getPassword() {
       return user.getPassword();
   }

   @Override
   public String getUsername() {
       return user.getUsername();
   }
  //@Override 
  public int getId(){
	  return user.getId();
  }

   @Override
   public boolean isAccountNonExpired() {
       return true;
   }

   @Override
   public boolean isAccountNonLocked() {
       return true;
   }

   @Override
   public boolean isCredentialsNonExpired() {
       return true;
   }

   @Override
   public boolean isEnabled() {
       return user.isEnabled();
   }

}