package myy803.courses_mgt_app_skeleton.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import myy803.courses_mgt_app_skeleton.dao.StudentRegistrationDAO;
import myy803.courses_mgt_app_skeleton.entity.StudentRegistration;

@Service
public class StudentRegistrationServiceImpl implements StudentRegistrationService {
	@Autowired
	private StudentRegistrationDAO studentregistrationRepository;
	
	public StudentRegistrationServiceImpl() {
		super();
	}

	@Autowired
	public StudentRegistrationServiceImpl(StudentRegistrationDAO theStudentRegistrationRepository) {
		studentregistrationRepository = theStudentRegistrationRepository;
	}
	@Override
	public List<StudentRegistration> findRegistrationsByCourseId(int courseid) {
		List<StudentRegistration> studentregistration= studentregistrationRepository.findRegistrationsByCourseId(courseid);
		return studentregistration;
	}
	@Override
	public void deleteById(int studentid) {
		studentregistrationRepository.deleteById(studentid);
		
	}
	public StudentRegistration saveStudentRegistration(StudentRegistration theStudentRegistration) {
		StudentRegistration StudentRegistration=studentregistrationRepository.save(theStudentRegistration);
		return StudentRegistration;
		
	}

	@Override
	public void update(StudentRegistration theStudentRegistration) {
		// TODO Auto-generated method stub
		
	}
	public StudentRegistration findById(int studentid) {
		StudentRegistration studentregistration = studentregistrationRepository.findById(studentid);
		return studentregistration;
	}
	public double getgrades(int studentid) {
		double grade = studentregistrationRepository.getgrades(studentid);
		return grade;
	}
	public double getprojecctgrades(int studentid) {
		double project = studentregistrationRepository.getprojecctgrades(studentid);
		return project;
	}

}
