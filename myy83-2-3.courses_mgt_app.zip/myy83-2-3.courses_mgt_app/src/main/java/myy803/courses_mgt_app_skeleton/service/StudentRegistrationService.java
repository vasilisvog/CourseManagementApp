package myy803.courses_mgt_app_skeleton.service;

import java.util.List;

import myy803.courses_mgt_app_skeleton.entity.StudentRegistration;

public interface StudentRegistrationService {
	
	public List<StudentRegistration> findRegistrationsByCourseId(int courseid);
	public void deleteById(int studentid);
	public void update(StudentRegistration theStudentRegistration);
	public StudentRegistration saveStudentRegistration(StudentRegistration theStudentRegistration);
	public StudentRegistration findById(int  studentid);
	public double getgrades(int studentid);
	public double getprojecctgrades(int studentid);
	

}
