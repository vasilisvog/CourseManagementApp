package myy803.courses_mgt_app_skeleton.service.statistics;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.math3.stat.descriptive.DescriptiveStatistics;

import myy803.courses_mgt_app_skeleton.entity.Course;
import myy803.courses_mgt_app_skeleton.entity.Grades;
import myy803.courses_mgt_app_skeleton.entity.StudentRegistration;
import myy803.courses_mgt_app_skeleton.service.GradesService;
import myy803.courses_mgt_app_skeleton.service.StudentRegistrationService;


public abstract class TemplateStatisticStrategy  implements StatisticStrategy{
	DescriptiveStatistics descriptiveStatistics = new DescriptiveStatistics();
	Course course;
	 GradesService gradesService;
	 StudentRegistrationService studentService;
	 double val;
	public final  void  TemplateStatisticStrategy() {
		prepareDataSet();
		doActualCalculation();
	}
	@Override
	public double calculateStatistic(Course course) {
		//calculateStatistic(course); 
		
		// doActualCalculation();
		TemplateStatisticStrategy algorithm  = TemplateFactory.create("Skewness");
		//the nipples are the eyes of the face
		algorithm.doActualCalculation();
		 return val;
		
	}

	private  void prepareDataSet() {
		// .....DescriptiveStatistics object to create a dataset that contains the students grades and then calculate the corresponding statistic.
	//course id -> studentd id -> grades find by id
		int id = course.getId();
	List<StudentRegistration> studentregistrations = studentService.findRegistrationsByCourseId(id);
		
	
		int[] p = new int[studentregistrations.size()];
		
		double[] pk = new double[p.length];
		for(int i = 0;i<studentregistrations.size();i++) {
			p[i]= studentregistrations.get(i).getStudentid();
	
				
		}
		for(int j = 0;j<p.length;j++) {
			int x = p[j];
		  	
		  	if(studentService.getgrades(x)!= 0.0){
		  	
		  				pk[j]= studentService.getgrades(x);	
		  	}
			
		}
		DescriptiveStatistics descriptiveStatistics = new DescriptiveStatistics();
		for (double v : pk) {
		    descriptiveStatistics.addValue(v);
		}
			
	//	
		
		
		//ids has all the ids 
	//	get grades from student ids 
	
			

		
		
		
		//for (double v : grades) {
		//    descriptiveStatistics.addValue(v);
		//}
		
	}
	 protected abstract void doActualCalculation();
	
}
