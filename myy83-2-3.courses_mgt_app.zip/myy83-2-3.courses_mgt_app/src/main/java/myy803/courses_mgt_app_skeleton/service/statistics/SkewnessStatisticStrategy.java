package myy803.courses_mgt_app_skeleton.service.statistics;


public class SkewnessStatisticStrategy extends TemplateStatisticStrategy {
	public SkewnessStatisticStrategy() {
		super();
	}
//	@Override
	//void prepareDataSet() {
		//System.out.println("preparing the dataset");
	//}
	@Override
	protected void doActualCalculation() {
	
		double skewness = descriptiveStatistics.getSkewness();
		System.out.println("this is the skewness " +skewness);
	}
}
