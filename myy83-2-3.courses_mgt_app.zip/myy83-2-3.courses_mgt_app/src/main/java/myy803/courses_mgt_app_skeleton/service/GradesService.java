package myy803.courses_mgt_app_skeleton.service;

import java.util.List;
import myy803.courses_mgt_app_skeleton.entity.Grades;

public interface GradesService {
	
	public List<Grades>  findById(int stid);
	public Grades addStudentGrades(int stid,float finalexam,float project);
	public Grades saveGrades(Grades grades);
	public void deleteById(int stid);
	public double getWeightedfinalgrade(double weight,double project,double finalgrade);

}
