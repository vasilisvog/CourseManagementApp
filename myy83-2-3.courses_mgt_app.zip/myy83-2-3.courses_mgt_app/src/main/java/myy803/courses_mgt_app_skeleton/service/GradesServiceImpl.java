package myy803.courses_mgt_app_skeleton.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import myy803.courses_mgt_app_skeleton.dao.GradesDAO;
import myy803.courses_mgt_app_skeleton.entity.Course;
import myy803.courses_mgt_app_skeleton.entity.Grades;

@Service
public class GradesServiceImpl implements GradesService {
	
	@Autowired
	private GradesDAO gradesRepository;
	private Grades grades;
	@Override
	public  List<Grades> findById(int stid) {
		 List<Grades>  grades = gradesRepository.findById(stid);
		return grades;
	}
	public Grades addStudentGrades(int stid,float finalexam,float project) {
		
		Grades grades = new Grades();
		grades.setStid(stid);
		grades.setFinalexam(finalexam);
		grades.setProject(project);
		
		return grades;
	}
	
	@Override
	public Grades saveGrades(Grades grades) {
		
		Grades grade=gradesRepository.save(grades);
		return grade;
	}
	
	@Override
	public void deleteById(int stid) {
		gradesRepository.deleteById(stid);		
	}
	@Override
	public double getWeightedfinalgrade(double weight,double finalexam,double project) {
		double finalgrade =0;
		if(finalexam >0.0 && project >0.0) {
			finalgrade = weight*finalexam+(1-weight)*project;
		}
		
		return finalgrade;
	}
	
}
