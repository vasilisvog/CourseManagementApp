package myy803.courses_mgt_app_skeleton.service.statistics;

import myy803.courses_mgt_app_skeleton.entity.Course;
// implements StatisticStrategy
public class ObjectStatisticStrategy {
/*	private Adaptee adaptee;

	public ObjectStatisticStrategy(Adaptee adaptee) {
		this.adaptee = adaptee;
	}

	@Override
	public double calculateStatistic(Course course) {
		double res = calculateStatistic(course);
		return res;
	}
*/
	
	
	
}
